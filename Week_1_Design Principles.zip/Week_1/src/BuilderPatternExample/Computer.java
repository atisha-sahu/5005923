package BuilderPatternExample;

public class Computer {
	private final String CPU;
    private final int RAM;
    private int storage;
    private boolean hasGraphicsCard;
    private boolean hasBluetooth;

    private Computer(Computer computer) {
        this.CPU = computer.CPU;
        this.RAM = computer.RAM;
        this.storage = computer.storage;
        this.hasGraphicsCard = computer.hasGraphicsCard;
        this.hasBluetooth = computer.hasBluetooth;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + "GB, Storage=" + storage + "GB, Graphics Card=" + (hasGraphicsCard ? "Yes" : "No") + ", Bluetooth=" + (hasBluetooth ? "Yes" : "No") + "]";
    }

    public static class Builder {
    	 private final String CPU; // Required
         private final int RAM; // Required
         private int storage = 0; // Optional
         private boolean hasGraphicsCard = false; // Optional
         private boolean hasBluetooth = false; // Optional

         public Builder(String CPU, int RAM) {
             this.CPU = CPU;
             this.RAM = RAM;
         }

		public Computer setStorage(int i) {
			// TODO Auto-generated method stub
			return null;
		}

		public Computer build() {
			// TODO Auto-generated method stub
			return null;
		}

		public Computer setBluetooth(boolean b) {
			// TODO Auto-generated method stub
			return null;
		}
    }
    public Computer setStorage(int storage) {
        this.storage = storage;
        return this;
    }

    public Computer setGraphicsCard(boolean hasGraphicsCard) {
        this.hasGraphicsCard = hasGraphicsCard;
        return this;
    }

    public Computer setBluetooth(boolean hasBluetooth) {
        this.hasBluetooth = hasBluetooth;
        return this;
    }
    public Computer build() {
        return new Computer(this);
    }



public class BuilderPatternTest {
/*private String cpu;
private int ram;
private String storage;
private boolean hasGraphicsCard;

private Computer(Computer computer) {
	this.cpu=computer.cpu;
	this.ram=computer.ram;
	this.storage=computer.storage;
	this.hasGraphicsCard=computer.hasGraphicsCard;
}




public String getCpu() {
return cpu;
}

public int getRam() {
return ram;
}

public String getStorage() {
return storage;
}

public boolean hasGraphicsCard() {
return hasGraphicsCard;
}

public static class Builder{
	private String cpu;
	private int ram;
	private String storage;
	private boolean hasGraphicsCard;
	public Object setcpu(String string) {
		// TODO Auto-generated method stub
		return null;
	}
}

public Computer setCpu(String cpu) {
    this.cpu = cpu;
    return this;
}

public Computer setRam(int ram) {
    this.ram = ram;
    return this;
}

public Computer setStorage(String storage) {
    this.storage = storage;
    return this;
}

public Computer setGraphicsCard(boolean hasGraphicsCard) {
    this.hasGraphicsCard =hasGraphicsCard;
    return this;
}

public Computer build() {
    return new Computer(this);
}

public class ComputerBuilderTest() {
	
}
*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* Computer computer =  new Computer.Builder()
				   .setcpu("Intel Core i3")
	               .setRAM(8)
	               .setStorage("500GB HDD")
	               .build();
		 
		 System.out.println("Basic Computer Configuration:");
	        System.out.println("CPU: " + computer.getCpu());
	        System.out.println("RAM: " + computer.getRam() + "GB");
	        System.out.println("Storage: " + computer.getStorage());
	        System.out.println("Has Graphics Card: " +computer.hasGraphicsCard());
	        System.out.println();   */
		Computer computer1 = new Computer.Builder("Intel i7", 16)
                .setStorage(512)
                .setGraphicsCard(true)
                .build();

        Computer computer2 = new Computer.Builder("AMD Ryzen 5", 8)
                .setBluetooth(true)
                .build();

        System.out.println(computer1);
        System.out.println(computer2);
    }
}
	}
	



