package ObserverPatternExample;
import java.util.ArrayList;
import java.util.List;


 interface Stock{
	void registerObserver(Observer observer);
	void deregisterObserver(Observer observer);
	void notifyObservers();
}
 
 class StockMarket implements Stock{
private List<Observer>observers;
private double stockPrice;

public StockMarket() {
	observers= new ArrayList<>();
}

public void registerObserver(Observer observer) {
	observers.add(observer);
}
 
 
 public void deregisterObserver(Observer observer) {
     observers.remove(observer);
 }

 @Override
 public void notifyObservers() {
     for (Observer observer : observers) {
         observer.update(stockPrice);
     }
 }
 
 public void setStockPrice(double price) {
     this.stockPrice = price;
     notifyObservers();
 }
}
 
  interface Observer {
	    void update(double stockPrice);
	}
  
  class MobileApp implements Observer {
	
	    public void update(double stockPrice) {
	        System.out.println("Mobile App: Stock price updated to $" + stockPrice);
	    }
	}
  
   class WebApp implements Observer {
	    public void update(double stockPrice) {
	        System.out.println("Web App: Stock price updated to $" + stockPrice);
	    }
	}
public class ObserverPatternTest {

	public static void main(String[] args) {
		StockMarket stockMarket = new StockMarket();
		 Observer mobileApp = new MobileApp(); //Register Observer
	        Observer webApp = new WebApp();
	        stockMarket.setStockPrice(100.50);
	        stockMarket.setStockPrice(102.75);
	        stockMarket.deregisterObserver(mobileApp);
	        stockMarket.setStockPrice(99.99);
	}

}
