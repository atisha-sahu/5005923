package SingletonPatternExample;



public class Logger {
	 public static Logger instance;
	    private Logger() {}
	    
	    public static Logger getInstance() {
	    	if(instance==null) {
	    		instance=new Logger();
	    	}
	    	return instance;
	    }
	    
	    public void log(String message) {
	    	System.out.println("Logged: " +message);
	    }
	    
	    public class LoggerTest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Logger logger1= Logger.getInstance();
		    Logger logger2=Logger.getInstance();
		    
		    System.out.println("Is logger1 the same as logger2 ?" + (logger1==logger2));
		    
		          logger1.log("Hello , World!");
		          logger2.log("This is another log message.");
			}
	}

}
