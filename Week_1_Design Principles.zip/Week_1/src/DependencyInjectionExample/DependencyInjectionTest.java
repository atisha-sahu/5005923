package DependencyInjectionExample;
interface CustomerRepository {
    String findCustomerById(int id);
}

 class CustomerRepositoryImpl implements CustomerRepository {
   
 public String findCustomerById(int id) {
   return "Customer with ID: " + id;
    }
}
 
 class CustomerService {
	    private CustomerRepository customerRepository;

public CustomerService(CustomerRepository customerRepository) {
this.customerRepository = customerRepository;
	    }

public String getCustomerDetails(int id) {
 return customerRepository.findCustomerById(id);
	    }
	}
public class DependencyInjectionTest {

	public static void main(String[] args) {
 CustomerRepository repository = new CustomerRepositoryImpl();
     
CustomerService service = new CustomerService(repository);
	        
String customerDetails = service.getCustomerDetails(1);
	    System.out.println(customerDetails);
	    }
	

	}


