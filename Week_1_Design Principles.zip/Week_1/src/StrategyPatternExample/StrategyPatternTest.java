package StrategyPatternExample;
interface PaymentStrategy {
    void pay(double amount);
}

 class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private String cardHolderName;

    public CreditCardPayment(String cardNumber, String cardHolderName) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }

    public void pay(double amount) {
        System.out.println("Paying $" + amount + " using Credit Card.");
        System.out.println("Card Number: " + cardNumber);
        System.out.println("Card Holder Name: " + cardHolderName);
    }
}
 
 class PayPalPayment implements PaymentStrategy {
	    private String email;

	    public PayPalPayment(String email) {
	        this.email = email;
	    }
	   
	    public void pay(double amount) {
	        System.out.println("Paying $" + amount + " using PayPal.");
	        System.out.println("Email: " + email);
	    }
	}
 
  class PaymentContext {
	    private PaymentStrategy paymentStrategy;

	    public PaymentContext(PaymentStrategy paymentStrategy) {
	        this.paymentStrategy = paymentStrategy;
	    }

	    public void executePayment(double amount) {
	        paymentStrategy.pay(amount);
	    }
	}
public class StrategyPatternTest {

	public static void main(String[] args) {
		
 PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432", "John Doe");
	PaymentContext paymentContext = new PaymentContext(creditCard);
    paymentContext.executePayment(100.0);
	PaymentStrategy payPal = new PayPalPayment("john.doe@example.com");
	paymentContext = new PaymentContext(payPal);
	paymentContext.executePayment(200.0);
	    }
	
	}


