package FactoryMethodPatternExample;

interface Document{
	void open();
	void save();
	void close();
}

class WordDocument implements Document{
	public void open() {
		System.out.println("Opening Word Document...");
	}
	
	public void save() {
		System.out.println("Saving Word Document...");
	}
	public void close() {
		System.out.println("Closing Word Document...");
	}
}
class PdfDocument implements Document{
public void open() {
	System.out.println("Opening Pdf Document...");
}

public void save() {
	System.out.println("Saving Pdf Document...");
}
public void close() {
	System.out.println("Closing Pdf Document...");
}
}

class ExcelDocument implements Document{
public void open() {
	System.out.println("Opening Excel Document...");
}

public void save() {
	System.out.println("Saving Excel Document...");
}
public void close() {
	System.out.println("Closing Excel Document...");
}
}

abstract class DocumentFactory{
	abstract Document createDocument();
	
}
class WordDocumentFactory extends DocumentFactory{
	Document createDocument() {
		return new WordDocument();
	}
}
class PdfDocumentFactory extends DocumentFactory{
	Document createDocument() {
		return new PdfDocument();
	}
}
class ExcelDocumentFactory extends DocumentFactory{
	Document createDocument() {
		return new ExcelDocument();
	}
}
public class Main {

	public static void main(String[] args) {
		  DocumentFactory wordFactory = new WordDocumentFactory();
	        Document wordDocument = wordFactory.createDocument();
	        wordDocument.open();
	        wordDocument.save();
	        wordDocument.close();

	        DocumentFactory pdfFactory = new PdfDocumentFactory();
	        Document pdfDocument = pdfFactory.createDocument();
	        pdfDocument.open();
	        pdfDocument.save();
	        pdfDocument.close();

	        DocumentFactory excelFactory = new ExcelDocumentFactory();
	        Document excelDocument = excelFactory.createDocument();
	        excelDocument.open();
	        excelDocument.save();
	        excelDocument.close();
	}

}
