public class FinancialForecastingTool {

    // Method to calculate future value recursively
    public static double calculateFutureValue(double presentValue, double growthRate, int periods) {
        // Base case: when periods are 0, the future value is the present value
        if (periods == 0) {
            return presentValue;
        }
        // Recursive case: calculate future value for the next period
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5% growth rate
        int periods = 10;

        double futureValue = calculateFutureValue(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods: " + futureValue);
    }
}

public class FinancialForecastingTool {

    // Method to calculate future value iteratively
    public static double calculateFutureValueIterative(double presentValue, double growthRate, int periods) {
        double futureValue = presentValue;
        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5% growth rate
        int periods = 10;

        double futureValueRecursive = calculateFutureValue(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods (Recursive): " + futureValueRecursive);

        double futureValueIterative = calculateFutureValueIterative(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods (Iterative): " + futureValueIterative);
    }
}

/*
 * public class FinancialForecastingTool {

    // Method to calculate future value recursively
    public static double calculateFutureValue(double presentValue, double growthRate, int periods) {
        // Base case: when periods are 0, the future value is the present value
        if (periods == 0) {
            return presentValue;
        }
        // Recursive case: calculate future value for the next period
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, periods - 1);
    }

    // Method to calculate future value iteratively
    public static double calculateFutureValueIterative(double presentValue, double growthRate, int periods) {
        double futureValue = presentValue;
        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5% growth rate
        int periods = 10;

        double futureValueRecursive = calculateFutureValue(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods (Recursive): " + futureValueRecursive);

        double futureValueIterative = calculateFutureValueIterative(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods (Iterative): " + futureValueIterative);
    }
}

 */